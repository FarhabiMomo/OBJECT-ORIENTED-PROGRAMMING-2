﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopClass
{
    class Product
    {
        private int id;
        private string name;
        private string manufectureDate;
        private double price;

        public int GetId()
        {
            return this.id;
        }
        public void SetId(int id)
        {
            if (id <= 0 && id >= 100000)
                this.id = id;
            else
                id = -1;
                //Console.WriteLine("the id is not in the range");
        }

        public string GetName()
        {
            return this.name;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public string GetManufectureDate()
        {
            return this.manufectureDate;
        }
        public void SetManufectureData(string manufectureDate)
        {
            this.manufectureDate = manufectureDate;
        }
        public double GetPrice()
        {
            return this.price;
        }
        public void SetPrice(double price)
        {
            if (price <= 0 && price >= 100000)
                this.price = price;
            else
                price = -1;
            
        }

        public Product()
        { }
        public Product(int id,string name, string manufectureDate,double price )
        {
            this.SetId(id);
            this.name = name;
            this.manufectureDate = manufectureDate;
            this.SetPrice(price);
        }
        public void ProductInfo()
        {
            Console.WriteLine("Show All the ProductInfo");
            Console.WriteLine("id: {0}", this.id);
            Console.WriteLine("name: {0}", this.name);
            Console.WriteLine("manufectureDate: {0}", this.manufectureDate);
            Console.WriteLine("price: {0}", this.price);
            Console.WriteLine("  ");


        }
    }
}
